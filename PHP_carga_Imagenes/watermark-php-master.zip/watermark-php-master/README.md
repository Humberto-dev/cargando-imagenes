Watermark images with php
=============

Version 1.0

PHP script to generate watermark on images.

http://www.pedroventura.com/php/crear-marcas-de-agua-con-php/

Feel free to improve this code


